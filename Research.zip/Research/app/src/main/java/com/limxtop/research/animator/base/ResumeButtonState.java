package com.limxtop.research.animator.base;

import android.view.View;

/**
 * Created by limxtop on 4/30/16.
 */
public class ResumeButtonState  extends AbstracteButtonState {

    @Override
    public void action(View view, int[] enables, int[] disables) {
        super.action(view, enables, disables);
    }
}
